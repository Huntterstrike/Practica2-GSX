# Architecture — Diagramas y explicación

## Diagrama ASCII\```
Internet
   │
   ▼
[ Node / Minikube IP ]  <-- NodePort / Ingress
   │
   ▼
[ NGINX (frontend) ]  (labels: app=nginx, env=prod)
   │
   ▼
[ Simple App (backend) ] (labels: app=simple-app, env=prod)
   │
   ▼
[ Redis ] (stateful, svc: redis, pvc if used)
\```

## Mermaid (copiar en viewer compatible):
```mermaid
flowchart TD
  Internet --> NodeIP[Node / Minikube IP]
  NodeIP --> NGINX[NGINX (app=nginx, env=prod)]
  NGINX --> APP[Simple App (app=simple-app, env=prod)]
  APP --> REDIS[Redis (stateful)]
  classDef prod fill:#e6f7ff,stroke:#0b69a3;
  class NGINX,APP,REDIS prod;
```

## NetworkPolicies recomendadas
- `00-default-deny.yml` → Policy por defecto: deny all ingress/egress en namespace `prod`
- `02-frontend-to-backend.yml` → Permitir nginx -> simple-app (puerto 5000)
- `03-backend-to-redis.yml` → Permitir simple-app -> redis (puerto 6379)
- `05-allow-dns.yml` → Permitir consultas DNS a CoreDNS
- `04-allow-nginx-ingress.yml` → Permitir tráfico externo (ingress) a nginx

## Flujo de tráfico (resumen)
1. Cliente externo -> NodeIP:NodePort (o Ingress Host) -> nginx
2. nginx -> simple-app (servicio interno)
3. simple-app -> redis para persistencia
4. Sólo nginx expuesto al exterior; backend y redis aislados mediante NetworkPolicies.
