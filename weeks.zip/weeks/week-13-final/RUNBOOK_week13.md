# RUNBOOK — Operaciones (Week 13)

## Acceso y comprobaciones básicas
- Verificar estado del clúster:
  ```bash
  kubectl cluster-info
  minikube status
  ```
- Ver estado general:
  ```bash
  kubectl get pods --all-namespaces -o wide
  kubectl get svc --all-namespaces -o wide
  kubectl get deploy --all-namespaces -o wide
  kubectl get networkpolicies --all-namespaces
  ```

## Logs
- Ver logs de un pod:
  ```bash
  kubectl logs -f <pod-name>
  ```
- Logs de un contenedor concreto:
  ```bash
  kubectl logs -f <pod-name> -c <container-name>
  ```

## Escalado
- Escalar nginx a 3 réplicas:
  ```bash
  kubectl scale deployment/nginx --replicas=3
  ```

## Despliegue de nueva versión (procedimiento seguro)
1. Construir imagen y etiquetar con SHA:
```bash
docker build -t youruser/simple-app:sha123 .
docker push youruser/simple-app:sha123
```
2. Actualizar manifest/IaC (image tag) y aplicar:
```bash
kubectl set image deployment/simple-app simple-app=youruser/simple-app:sha123
kubectl rollout status deployment/simple-app
```

## Rollback
- Si falla tras deploy:
  ```bash
  kubectl rollout undo deployment/simple-app
  ```

## Backups y persistencia
- Si usas PVC: documentar snapshots o usar Velero.
- Redis: si se usa RDB/AOF, exportar dump antes de mantenimiento.

## Mantenimiento programado
- Actualizar imágenes y parches fuera de la demo.
- Probar cambios en entorno `staging` antes de `prod` (si aplica).
