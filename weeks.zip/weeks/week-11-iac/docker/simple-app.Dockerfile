FROM python:3.12-alpine

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PORT=5000

WORKDIR /app

RUN addgroup -S app && adduser -S app -G app

COPY weeks/week-09-compose/docker-compose/simple-app/requirements.txt ./requirements.txt
RUN pip install --no-cache-dir -r requirements.txt

COPY weeks/week-09-compose/docker-compose/simple-app/app.py ./app.py
RUN chown -R app:app /app

USER app

EXPOSE 5000

HEALTHCHECK --interval=30s --timeout=3s \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:5000/health')" || exit 1

CMD ["python", "app.py"]
